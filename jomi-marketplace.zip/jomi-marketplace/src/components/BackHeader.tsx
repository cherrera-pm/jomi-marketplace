import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";

export default function BackHeader({
  title,
  fallbackTo = "/",
}: {
  title?: string;
  fallbackTo?: string;
}) {
  const navigate = useNavigate();

  const goBack = () => {
    // Si hay historial previo, vuelve; si no, navega al catálogo
    if (window.history.length > 1) navigate(-1);
    else navigate(fallbackTo);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="mx-auto max-w-md h-12 px-2 flex items-center gap-2">
        <button
          onClick={goBack}
          className="p-2 rounded-full hover:bg-slate-100"
          aria-label="Volver"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h1 className="text-sm font-medium truncate">
          {title ?? "Volver al catálogo"}
        </h1>
      </div>
    </header>
  );
}
