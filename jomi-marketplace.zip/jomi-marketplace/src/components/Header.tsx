import { Link } from "react-router-dom";
import { ShoppingCart } from "lucide-react";
import logo from "@/assets/logo.svg";
import { useCart } from "@/features/cart/CartStore";
import { useStoreSlug } from "@/lib/useStoreSlug";

export default function Header() {
  const storeSlug = useStoreSlug();
  const totalQty = useCart((s) => s.lines.reduce((acc, l) => acc + l.qty, 0));
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="mx-auto max-w-md px-3 h-14 flex items-center justify-between">
        {/* Logo */}
        <Link to={`/${storeSlug}`} className="flex items-center gap-2">
          <img src={logo} alt="Jomi Marketplace" className="h-8 w-auto" />
        </Link>

        {/* Carrito */}
        <Link
          to={`/${storeSlug}/cart`}
          className="relative p-2 rounded-full hover:bg-slate-100 transition"
        >
          <ShoppingCart className="w-6 h-6 text-slate-700" />
          {totalQty > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] leading-4 min-w-[18px] h-[18px] rounded-full grid place-items-center px-1">
              {totalQty}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
